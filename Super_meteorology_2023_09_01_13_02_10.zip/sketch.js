function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
let circle1;
let circle2;
let mergedShape;
let radius = 50;
let merged = false;

function setup() {
  createCanvas(400, 400);
  background(255); // Establecer el fondo en blanco
  circle1 = createVector(100, height / 2);
  circle2 = createVector(300, height / 2);
}

function draw() {
  // Calcula la distancia entre los dos círculos
  let d = dist(circle1.x, circle1.y, circle2.x, circle2.y);

  // Si los círculos colisionan (la distancia es menor que el diámetro),
  // establece "merged" en true
  if (d < 2 * radius) {
    merged = true;
  }

  // Si los círculos no han fusionado, muévelos hacia el centro
  if (!merged) {
    circle1.x += 1;
    circle2.x -= 1;
  }

  // Fondo blanco en cada cuadro
  background(255);

  // Si los círculos han fusionado, dibuja un cuadrado en lugar de los círculos
  if (merged) {
    fill(255, 0, 0); // Rojo
    let squareSize = radius * 2;
    mergedShape = createVector((circle1.x + circle2.x) / 2, height / 2);
    rect(mergedShape.x - squareSize / 2, mergedShape.y - squareSize / 2, squareSize, squareSize);
  } else {
    fill(0); // Negro
    // Dibuja el primer círculo
    ellipse(circle1.x, circle1.y, 2 * radius);
    // Dibuja el segundo círculo
    ellipse(circle2.x, circle2.y, 2 * radius);
  }
}

